# computer_vision
## my work for python/image processing.


## also contains a lot of stuff learnt over comp vision blogs...


~Rahul;
